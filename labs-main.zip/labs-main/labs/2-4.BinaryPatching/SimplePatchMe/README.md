# SimplePatchMe
Download `main.exe` and go to [the lesson in my note repository](https://notes.huskyhacks.dev/notes/on-patching-binaries) for this section of the course.

## Safety Note
This binary sample is not zipped and password protected because it is completely benign. The source code is included in the Note page if you care to inspect it. It was not necessary to make this sample emulate real malware to convey the concepts in the lesson.
