Analyst,

I'm -REALLY- sorry about this, but I have samples to triage and I won't be able to get to them today. There are only a few of them (26 total LMAO). Can you handle them for me? Thanks!

-Other Analyst

---

## Blue-Jupyter Install

Git clone the special `PMAT-lab` branch of Blue-Jupyter:
```
$ git clone --branch PMAT-lab https://github.com/HuskyHacks/blue-jupyter.git 
```

Then, follow the instructions in the repo!