Hey Analyst,

We've been incorporating new threat intel into our recent hunts and have taken a keen interest in MSIs. This one is the installer for a popular notetaking app, Notely. But the file hash does not match the one on the Notely main site.

We also pulled another file from the endpoint that was downloaded from the initial drop. Please analyze and send the report when ready.

-Threat Hunter Team