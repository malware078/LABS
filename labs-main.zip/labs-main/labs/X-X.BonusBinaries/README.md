 # Bonus Binaries

 The bonus binaries are samples that I developed for this course that did not make it into the course material. They were either too unstable, didn't have the correct difficulty curve, or were too difficult to execute correctly. If you're looking for more RE, try these out!
