Analyst! Help! We've been hit by ransomware!

The IR team is calling this one "WannaHusky" and it's demanding 100 Huskycoin in order to decrypt the contents of our files. Please help!

-C Suite
